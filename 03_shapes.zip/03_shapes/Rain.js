class Rain {
    constructor() {
        //And these are their properties
        //Constructs an object when told
        //this assigns a value to the parameters of an object (In this case X and Y)
        this.x = random(width/5,width/1.2);
        this.y = random(-420,-10);
      }

      update() {

        


        fill('black');
      
        noStroke();

   
        ellipse(this.x,this.y,3,20);
       
   
        this.y += 2;
          if (this.y > 420) {
            this.x = random(width/5,width/1.2);
            this.y = random(-420,-10);
          }
      }
    
  
  }


  
 



//   class Rain {
//     constructor() {
//       this.x = width/2;
//       this.y = height/2;
//       this.diameter = 100;
     
//     }

//     move() {
//         this.x += random(-this.speed, this.speed);
//         this.y += random(-this.speed, this.speed);
//       }
  
  
//     display() {
//       ellipse(this.x, this.y, this.diameter, this.diameter);
//     }
//   }
