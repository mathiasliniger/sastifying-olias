'use strict';

let shapeId = 1
let rain;
var rainDrop = [];
let mic;

function setup() {
    createCanvas(windowWidth, windowHeight);

    angleMode(DEGREES)
    // rain = new Rain();

    
    for (var inc = 100; inc < 300; inc++) {
        rainDrop[inc] = new Rain();
      }

      mic = new p5.AudioIn();
      mic.start();

     
      
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}

// function mouseClicked() {
//     shapeId++
//     shapeId %= 5
// }

function draw() {

    var vol = mic.getLevel();
    console.log(vol);

    background(255);
    
    fill(0,0,0,vol*5)
    noStroke()

    // push(new Rain({ color: color("black")}));
    push()
    translate(-10, width/2);

    for (var inc = 100 ; inc < 300; inc++ ) {
        rainDrop[inc].update() ;
      }

      pop()
     

    const sceneSize = min(width, height)

    const centerX = width / 2
    const centerY = height / 2
    const objSize = sceneSize / 2
    const halfWidth = objSize / tan(60)

    switch (shapeId) {
        

        case 1:
            arc(centerX, centerY * 0.5, sceneSize, sceneSize, 0, 180)
            break;

            
           
        

     

      
    }

    // rain.move();
    // rain.display();

}


